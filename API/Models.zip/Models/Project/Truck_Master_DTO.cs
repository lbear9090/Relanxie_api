﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Truck_Master_DTO
    {
        public Int64 TR_PKeyID { get; set; }
        public String TR_Name { get; set; }
        public String TR_Description { get; set; }
        public String TR_ImagePath { get; set; }
        public String TR_TruckNo { get; set; }
        public int? TR_NoOfTyre { get; set; }
        public Boolean? TR_IsActive { get; set; }
        public Boolean? TR_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}