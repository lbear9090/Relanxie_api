﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace API.Repository.Project
{
    public class Tyre_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Tyre_Master(Tyre_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Tyre_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@Tyre_PKeyID", 1 + "#bigint#" + model.Tyre_PKeyID);
                input_parameters.Add("@Tyre_Name", 1 + "#varchar#" + model.Tyre_Name);
                input_parameters.Add("@Tyre_Diameter", 1 + "#int#" + model.Tyre_Diameter);
                input_parameters.Add("@Tyre_Width", 1 + "#int#" + model.Tyre_Width);
                input_parameters.Add("@Tyre_Weight", 1 + "#varchar#" + model.Tyre_Weight);
                input_parameters.Add("@Tyre_Treaddepth", 1 + "#varchar#" + model.Tyre_Treaddepth);
                input_parameters.Add("@Tyre_Description", 1 + "#nvarchar#" + model.Tyre_Description);
                input_parameters.Add("@Tyre_MaximumRange", 1 + "#varchar#" + model.Tyre_MaximumRange);
                input_parameters.Add("@Tyre_Mileage", 1 + "#varchar#" + model.Tyre_Mileage);
                input_parameters.Add("@Tyre_Price", 1 + "#decimal#" + model.Tyre_Price);
                input_parameters.Add("@Tyre_Disc_Price", 1 + "#decimal#" + model.Tyre_Disc_Price);
                input_parameters.Add("@Tyre_Disc_Percentage", 1 + "#decimal#" + model.Tyre_Disc_Percentage);
                input_parameters.Add("@Tyre_RoInfo", 1 + "#varchar#" + model.Tyre_RoInfo);
                input_parameters.Add("@Tyre_BR_PKeyID", 1 + "#bigint#" + model.Tyre_BR_PKeyID);
                input_parameters.Add("@Tyre_AP_PKeyID", 1 + "#bigint#" + model.Tyre_AP_PKeyID);
                input_parameters.Add("@Tyre_SZ_PKeyID", 1 + "#bigint#" + model.Tyre_SZ_PKeyID);
                input_parameters.Add("@Tyre_IsActive", 1 + "#bit#" + model.Tyre_IsActive);
                input_parameters.Add("@Tyre_IsDelete", 1 + "#bit#" + model.Tyre_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@Tyre_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }

        private DataSet Get_Tyre_Master(Tyre_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Tyre_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@Tyre_PKeyID", 1 + "#bigint#" + model.Tyre_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> CreateUpdate_Tyre_Master_DataDetails(Tyre_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Tyre_Master(model);
                Product_Image_Data product_Image_Data = new Product_Image_Data();
                if (!string.IsNullOrEmpty(model.Pro_Images))
                {
                    var Data = JsonConvert.DeserializeObject<List<Product_Image_DTO>>(model.Pro_Images);
                    for (int i = 0; i < Data.Count; i++)
                    {
                        Data[i].UserID = model.UserID;
                        Data[i].ProImage_Pro_ID = objData[0];
                        if (Data[i].Type == 0)
                        {
                            Data[i].Type = 1;
                        }
                        if (Data[i].ProImage_ID == 0)
                        {
                            product_Image_Data.CreateUpdate_Product_Image_DataDetails(Data[i]);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        private List<Product_Image_DTO> GetProductImage(DataTable dt)
        {
            List<Product_Image_DTO> Product_Image_DTO = new List<Product_Image_DTO>();
            try
            {
                var myEnumerableFeaprd = dt.AsEnumerable();
                Product_Image_DTO =
                   (from item in myEnumerableFeaprd
                    select new Product_Image_DTO
                    {
                        ProImage_ID = item.Field<Int64>("ProImage_ID"),
                        ProImage_Pro_ID = item.Field<Int64?>("ProImage_Pro_ID"),
                        ProImage_ImageName = item.Field<String>("ProImage_ImageName"),
                        ProImage_size = item.Field<int?>("ProImage_size"),
                        ProImage_ImagePath = item.Field<String>("ProImage_ImagePath"),
                        ProImage_IsFirst = item.Field<Boolean?>("ProImage_IsFirst"),
                        ProImage_Number = item.Field<int?>("ProImage_Number"),
                        ProImage_IsActive = item.Field<Boolean?>("ProImage_IsActive"),
                    }).ToList();

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return Product_Image_DTO;

        }

        public List<dynamic> Get_Tyre_MasterDetails(Tyre_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Tyre_Master(model);
                if (model.Type == 2)
                {
                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<Tyre_Master_DTO> Get_details =
                       (from item in myEnumerableFeaprd
                        select new Tyre_Master_DTO
                        {
                            Tyre_PKeyID = item.Field<Int64>("Tyre_PKeyID"),
                            Tyre_Name = item.Field<String>("Tyre_Name"),
                            Tyre_Diameter = item.Field<int?>("Tyre_Diameter"),
                            Tyre_Width = item.Field<int?>("Tyre_Width"),
                            Tyre_Weight = item.Field<String>("Tyre_Weight"),
                            Tyre_Treaddepth = item.Field<String>("Tyre_Treaddepth"),
                            Tyre_Description = item.Field<String>("Tyre_Description"),
                            Tyre_MaximumRange = item.Field<String>("Tyre_MaximumRange"),
                            Tyre_Mileage = item.Field<String>("Tyre_Mileage"),
                            Tyre_Price = item.Field<Decimal?>("Tyre_Price"),
                            Tyre_Disc_Price = item.Field<Decimal?>("Tyre_Disc_Price"),
                            Tyre_Disc_Percentage = item.Field<Decimal?>("Tyre_Disc_Percentage"),
                            Tyre_RoInfo = item.Field<String>("Tyre_RoInfo"),
                            Tyre_BR_PKeyID = item.Field<Int64?>("Tyre_BR_PKeyID"),
                            Tyre_AP_PKeyID = item.Field<Int64?>("Tyre_AP_PKeyID"),
                            Tyre_SZ_PKeyID = item.Field<Int64?>("Tyre_SZ_PKeyID"),
                            Tyre_IsActive = item.Field<Boolean?>("Tyre_IsActive"),
                            product_Image_DTOs = GetProductImage(ds.Tables[1])
                        }).ToList();

                    objDynamic.Add(Get_details);
                }
                else
                {
                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<Tyre_Master_DTO> Get_details =
                       (from item in myEnumerableFeaprd
                        select new Tyre_Master_DTO
                        {
                            Tyre_PKeyID = item.Field<Int64>("Tyre_PKeyID"),
                            Tyre_Name = item.Field<String>("Tyre_Name"),
                            Tyre_Diameter = item.Field<int?>("Tyre_Diameter"),
                            Tyre_Width = item.Field<int?>("Tyre_Width"),
                            Tyre_Weight = item.Field<String>("Tyre_Weight"),
                            Tyre_Treaddepth = item.Field<String>("Tyre_Treaddepth"),
                            Tyre_Description = item.Field<String>("Tyre_Description"),
                            Tyre_MaximumRange = item.Field<String>("Tyre_MaximumRange"),
                            Tyre_Mileage = item.Field<String>("Tyre_Mileage"),
                            Tyre_Price = item.Field<Decimal?>("Tyre_Price"),
                            Tyre_Disc_Price = item.Field<Decimal?>("Tyre_Disc_Price"),
                            Tyre_Disc_Percentage = item.Field<Decimal?>("Tyre_Disc_Percentage"),
                            Tyre_RoInfo = item.Field<String>("Tyre_RoInfo"),
                            Tyre_BR_PKeyID = item.Field<Int64?>("Tyre_BR_PKeyID"),
                            Tyre_AP_PKeyID = item.Field<Int64?>("Tyre_AP_PKeyID"),
                            Tyre_SZ_PKeyID = item.Field<Int64?>("Tyre_SZ_PKeyID"),
                            Tyre_IsActive = item.Field<Boolean?>("Tyre_IsActive"),
                            
                        }).ToList();

                    objDynamic.Add(Get_details);
                }
              
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }


        private DataSet Get_Tyre_Master(DropDown_Tyre_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_DropDown_Tyre]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@BR_PKeyID", 1 + "#bigint#" + model.BR_PKeyID);
                input_parameters.Add("@AP_PKeyID", 1 + "#bigint#" + model.AP_PKeyID);
                input_parameters.Add("@SZ_PKeyID", 1 + "#bigint#" + model.SZ_PKeyID);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> Get_DropDown_TyreDetails(DropDown_Tyre_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {


                DataSet ds = Get_Tyre_Master(model);
                if (model.Type == 1)
                {


                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<DropDown_Tyre_DTO> PCRdrdDamge =
                       (from item in myEnumerableFeaprd
                        select new DropDown_Tyre_DTO
                        {
                            BR_PKeyID = item.Field<Int64>("BR_PKeyID"),
                            BR_Name = item.Field<String>("BR_Name"),



                        }).ToList();

                    objDynamic.Add(PCRdrdDamge);

                }
                if (model.Type == 2)
                {


                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<DropDown_Tyre_DTO> PCRdrdDamge =
                       (from item in myEnumerableFeaprd
                        select new DropDown_Tyre_DTO
                        {

                            AP_PKeyID = item.Field<Int64?>("AP_PKeyID"),
                            AP_Name = item.Field<String>("AP_Name"),


                        }).ToList();

                    objDynamic.Add(PCRdrdDamge);

                }
                if (model.Type == 3)
                {


                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<DropDown_Tyre_DTO> PCRdrdDamge =
                       (from item in myEnumerableFeaprd
                        select new DropDown_Tyre_DTO
                        {

                            SZ_PKeyID = item.Field<Int64?>("SZ_PKeyID"),
                            SZ_Name = item.Field<String>("SZ_Name"),


                        }).ToList();

                    objDynamic.Add(PCRdrdDamge);

                }

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}