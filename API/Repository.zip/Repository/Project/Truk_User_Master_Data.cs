﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;


namespace API.Repository.Project
{
    public class Truk_User_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Truk_User_Master(Truk_User_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Truk_User_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@TUM_PKeyID", 1 + "#bigint#" + model.TUM_PKeyID);
                input_parameters.Add("@TUM_TR_PKeyID", 1 + "#bigint#" + model.TUM_TR_PKeyID);
                input_parameters.Add("@TUM_User_PkeyID", 1 + "#bigint#" + model.TUM_User_PkeyID);
                input_parameters.Add("@TUM_TruckNo", 1 + "#nvarchar#" + model.TUM_TruckNo);
                input_parameters.Add("@TUM_Model", 1 + "#nvarchar#" + model.TUM_Model);
                input_parameters.Add("@TUM_Mileage", 1 + "#int#" + model.TUM_Mileage);
                input_parameters.Add("@TUM_Tyre_Date", 1 + "#datetime#" + model.TUM_Tyre_Date);
                input_parameters.Add("@TUM_IsActive", 1 + "#bit#" + model.TUM_IsActive);
                input_parameters.Add("@TUM_IsDelete", 1 + "#bit#" + model.TUM_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@TUM_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }

        private DataSet Get_Truk_User_Master(Truk_User_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truk_User_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TUM_PKeyID", 1 + "#bigint#" + model.TUM_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }

        public List<dynamic> CreateUpdate_Truk_User_Master_DataDetails(Truk_User_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Truk_User_Master(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        public List<dynamic> Get_Truk_User_MasterDetails(Truk_User_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truk_User_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Truk_User_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Truk_User_Master_DTO
                    {
                        TUM_PKeyID = item.Field<Int64>("TUM_PKeyID"),
                        TUM_TR_PKeyID = item.Field<Int64?>("TUM_TR_PKeyID"),
                        TUM_User_PkeyID = item.Field<Int64?>("TUM_User_PkeyID"),
                        TUM_TruckNo = item.Field<String>("TUM_TruckNo"),
                        TUM_Model = item.Field<String>("TUM_Model"),
                        TUM_Mileage = item.Field<int?>("TUM_Mileage"),
                        TUM_Tyre_Date = item.Field<DateTime?>("TUM_Tyre_Date"),
                        TUM_IsActive = item.Field<Boolean?>("TUM_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}