﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Tyre_Master_DTO
    {
        public Int64 Tyre_PKeyID { get; set; }
        public String Tyre_Name { get; set; }
        public int? Tyre_Diameter { get; set; }
        public int? Tyre_Width { get; set; }
        public String Tyre_Weight { get; set; }
        public String Tyre_Treaddepth { get; set; }
        public String Tyre_Description { get; set; }
        public String Tyre_MaximumRange { get; set; }

        public String Tyre_Mileage { get; set; }
        public Decimal? Tyre_Price { get; set; }
        public Decimal? Tyre_Disc_Price { get; set; }
        public Decimal? Tyre_Disc_Percentage { get; set; }
        public String Tyre_RoInfo { get; set; }
        public Int64? Tyre_BR_PKeyID { get; set; }
        public Int64? Tyre_AP_PKeyID { get; set; }
        public Int64? Tyre_SZ_PKeyID { get; set; }

        public Boolean? Tyre_IsActive { get; set; }
        public Boolean? Tyre_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }

        public string Pro_Images { get; set; }
        public string ProImage_ImagePath { get; set; }
        public List<Product_Image_DTO> product_Image_DTOs { get; set; }
    }

    public class DropDown_Tyre_DTO
    {
        public Int64 BR_PKeyID { get; set; }
        public String BR_Name { get; set; }
        public Int64? AP_PKeyID { get; set; }
        public String AP_Name { get; set; }

        public Int64? SZ_PKeyID { get; set; }
        public String SZ_Name { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}