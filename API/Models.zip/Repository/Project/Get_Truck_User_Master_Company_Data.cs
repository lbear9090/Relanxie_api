﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace API.Repository.Project
{
    public class Get_Truck_User_Master_Company_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();
        private DataSet Get_Truck_User_Master_Company(Get_Truck_User_Master_Company_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truck_User_Master_Company]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TUM_PKeyID", 1 + "#bigint#" + model.TUM_PKeyID);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }

        public List<dynamic> Get_Truck_User_Master_CompanyDetails(Get_Truck_User_Master_Company_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truck_User_Master_Company(model);
               
                
                    var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                    List<Get_Truck_User_Master_Company_DTO> Get_details =
                       (from item in myEnumerableFeaprd
                        select new Get_Truck_User_Master_Company_DTO
                        {
                            TUM_PKeyID = item.Field<Int64>("TUM_PKeyID"),
                            TUM_TR_PKeyID = item.Field<Int64?>("TUM_TR_PKeyID"),
                            TUM_TruckNo = item.Field<String>("TUM_TruckNo"),
                            TUM_Model = item.Field<String>("TUM_Model"),
                            TUM_Mileage = item.Field<int?>("TUM_Mileage"),
                            TUM_User_PkeyID = item.Field<Int64?>("TUM_User_PkeyID"),
                            TR_Name = item.Field<String>("TR_Name"),
                            TR_Description = item.Field<String>("TR_Description"),
                            TR_ImagePath = item.Field<String>("TR_ImagePath"),
                            TR_TruckNo = item.Field<String>("TR_TruckNo"),
                            User_Name = item.Field<String>("User_Name"),
                        }).ToList();

                    objDynamic.Add(Get_details);
                }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}