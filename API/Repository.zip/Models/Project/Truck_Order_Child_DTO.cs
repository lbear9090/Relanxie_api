﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Truck_Order_Child_DTO
    {
        public Int64 TOC_PkeyID { get; set; }
        public Int64? TOC_TOM_PkeyID { get; set; }
        public Int64? TOC_Tyre_PKeyID { get; set; }
        public int? TOC_Qty { get; set; }
        public Decimal? TOC_Tyre_Price { get; set; }
        public Decimal? TOC_Disc_Per { get; set; }
        public Decimal? TOC_Disc_Amount { get; set; }
        public Decimal? TOC_Total_Amount { get; set; }

        public Int64? TOC_User_PkeyID { get; set; }

        public Boolean? TOC_IsActive { get; set; }
        public Boolean? TOC_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}