﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Avigma.Models
{
    public class GenericClassDTO
    {
        public int intHrs { get; set; }
        public int intMins { get; set; }
    }
}