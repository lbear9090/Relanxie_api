﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;


namespace API.Repository.Project
{
    public class Truck_User_Master_Mileage_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Truck_User_Master_Mileage(Truck_User_Master_Mileage_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Truck_User_Master_Mileage]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@TUMM_PKeyID", 1 + "#bigint#" + model.TUMM_PKeyID);
                input_parameters.Add("@TUMM_TUM_PKeyID", 1 + "#bigint#" + model.TUMM_TUM_PKeyID);
                input_parameters.Add("@TUMM_Tyre_General_Condition", 1 + "#bit#" + model.TUMM_Tyre_General_Condition);
                input_parameters.Add("@TUMM_Torque_Checked", 1 + "#bit#" + model.TUMM_Torque_Checked);
                input_parameters.Add("@TUMM_Tread_Depth", 1 + "#bit#" + model.TUMM_Tread_Depth);
                input_parameters.Add("@TUMM_Trye_Pressure", 1 + "#bit#" + model.TUMM_Trye_Pressure);
                input_parameters.Add("@TUMM_Comments", 1 + "#varchar#" + model.TUMM_Comments);
                input_parameters.Add("@TUMM_Mileage", 1 + "#int#" + model.TUMM_Mileage);
                input_parameters.Add("@TUMM_Last_Inspection", 1 + "#datetime#" + model.TUMM_Last_Inspection);
                input_parameters.Add("@TUMM_IsActive", 1 + "#bit#" + model.TUMM_IsActive);
                input_parameters.Add("@TUMM_IsDelete", 1 + "#bit#" + model.TUMM_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@TUMM_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Truck_User_Master_Mileage(Truck_User_Master_Mileage_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truck_User_Master_Mileage]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TUMM_PKeyID", 1 + "#bigint#" + model.TUMM_PKeyID);
                input_parameters.Add("@TUMM_TUM_PKeyID", 1 + "#bigint#" + model.TUMM_TUM_PKeyID);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }

        public List<dynamic> CreateUpdate_Truck_User_Master_Mileage_DataDetails(Truck_User_Master_Mileage_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Truck_User_Master_Mileage(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        public List<dynamic> Get_Truck_User_Master_MileageDetails(Truck_User_Master_Mileage_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truck_User_Master_Mileage(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Truck_User_Master_Mileage_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Truck_User_Master_Mileage_DTO
                    {
                        TUMM_PKeyID = item.Field<Int64>("TUMM_PKeyID"),
                        TUMM_TUM_PKeyID = item.Field<Int64>("TUMM_TUM_PKeyID"),
                        TUMM_Tyre_General_Condition = item.Field<Boolean?>("TUMM_Tyre_General_Condition"),
                        TUMM_Torque_Checked = item.Field<Boolean?>("TUMM_Torque_Checked"),
                        TUMM_Tread_Depth = item.Field<Boolean?>("TUMM_Tread_Depth"),
                        TUMM_Trye_Pressure = item.Field<Boolean?>("TUMM_Trye_Pressure"),
                        TUMM_Comments = item.Field<String>("TUMM_Comments"),
                        TUMM_Mileage = item.Field<int?>("TUMM_Mileage"),
                        TUMM_Last_Inspection = item.Field<DateTime?>("TUMM_Last_Inspection"),

                        TUMM_IsActive = item.Field<Boolean?>("TUMM_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}