﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Web.Http.Cors;
using Avigma.Repository.Lib;
using API.Models.Project;
using API.Repository.Project;
using Avigma.Models;
namespace API.Controllers
{
    [RoutePrefix("api/GripMaster")]
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class GripMasterController : BaseController
    {
        Log log = new Log();
        Tyre_Master_Data tyre_Master_Data = new Tyre_Master_Data();
        UserMaster_Data userMaster_Data = new UserMaster_Data();
        Brand_Master_Data Brand_Master_Data = new Brand_Master_Data();
        Size_Master_Data size_Master_Data = new Size_Master_Data();
        Fleet_Master_Data fleet_Master_Data = new Fleet_Master_Data();
        Application_Master_Data application_Master_Data = new Application_Master_Data();
        Truck_Master_Data truck_Master_Data = new Truck_Master_Data();
        Truk_User_Master_Data Truk_User_Master_Data = new Truk_User_Master_Data();
        Truck_Order_Master_Data Truck_Order_Master_Data = new Truck_Order_Master_Data();
        Truck_Order_Child_Data Truck_Order_Child_Data = new Truck_Order_Child_Data();
        User_Address_Master_Data User_Address_Master_Data = new User_Address_Master_Data();
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("AddUserMasterData")]
        public async Task<List<dynamic>> AddUserMasterData()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {

                

                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage(s);
                var Data = JsonConvert.DeserializeObject<UserMaster_DTO>(s);
                Data.UserID = LoggedInUserId;
                if (Data.Type != 1)
                {
                    if (Data.Type == 8)
                    {
                        Data.Type = 2;
                    }
                    else if (Data.Type != 9)
                    {
                        Data.User_PkeyID = LoggedInUserId;
                    }

                }
                var userMasterDetails = await Task.Run(() => userMaster_Data.AddUserMaster_Data(Data));

                return userMasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetUserMasterData")]
        public async Task<List<dynamic>> GetUserMasterData()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
               
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage(s);
                var Data = JsonConvert.DeserializeObject<UserMaster_DTO>(s);
                Data.UserID = LoggedInUserId;
                if (Data.Type != 1)
                {
                    if (Data.Type == 4)
                    {
                        Data.Type = 2;
                    }
                    else
                    {
                        Data.User_PkeyID = LoggedInUserId;
                    }

                }
                var userMasterDetails = await Task.Run(() => userMaster_Data.Get_UserMasterDetails(Data));

                return userMasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("UploadImages")]
        public async Task<List<dynamic>> UploadImages()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {

                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage(s);
                var Data = JsonConvert.DeserializeObject<ImageData>(s);
                ImageGenerator imageGenerator = new ImageGenerator();
                var ImageData = await Task.Run(() => imageGenerator.GetImagePath(Data));

                return ImageData;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("UploadQRImages")]
        public async Task<List<dynamic>> UploadQRImages()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {

                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage(s);
                var Data = JsonConvert.DeserializeObject<QRCodeModelDTO>(s);
                QRCodeGenerator imageGenerator = new QRCodeGenerator();
                var ImageData = await Task.Run(() => imageGenerator.GenerateQRImage(Data));

                return ImageData;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }

        [HttpPost]
        [Route("ForGotPassword")]
        public async Task<List<dynamic>> ForGotPassword()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                GetSetUser getSetUser = new GetSetUser();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------ForGotPassword Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------ForGotPassword End--------------");
                var user_Child_DTO = JsonConvert.DeserializeObject<UserLogin>(s);


                var MasterDetails = await Task.Run(() => getSetUser.GetForGetPassword(user_Child_DTO));

                return MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetVerificationLink")]
        public async Task<List<dynamic>> GetVerificationLink()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                GetSetUser getSetUser = new GetSetUser();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------GetVerificationLink Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------GetVerificationLink End--------------");
                var user_Child_DTO = JsonConvert.DeserializeObject<UserLogin>(s);
                user_Child_DTO.User_PkeyID = LoggedInUserId;
                user_Child_DTO.UserID = LoggedInUserId;

                var MasterDetails = await Task.Run(() => getSetUser.GetVerificationLink(user_Child_DTO));

                return MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }


        [HttpPost]
        [Route("GetUserViryficationDetails")]
        public async Task<List<dynamic>> GetUserViryficationDetails()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                UserVerificationMaster_Data userVerificationMaster_Data = new UserVerificationMaster_Data();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------GetUserViryficationDetails Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------GetUserViryficationDetails End--------------");
                //log.logDebugMessage(s);
                var Data = JsonConvert.DeserializeObject<UserVerificationMaster_DTO>(s);
                //Data.Type = 1;

                var Getuser = await Task.Run(() => userVerificationMaster_Data.Check_User(Data));
                return Getuser;

            }
            catch (Exception ex)
            {

                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }



        [HttpPost]
        [Route("VerifyUserByEmail")]
        public async Task<List<dynamic>> VerifyUserByEmail()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                UserVerificationMaster_Data userVerificationMaster_Data = new UserVerificationMaster_Data();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------VerifyUserByEmail Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------VerifyUserByEmail End--------------");
           
                var Data = JsonConvert.DeserializeObject<UserMaster_DTO>(s);
              

                var Getuser = await Task.Run(() => userMaster_Data.VerifyUserByEmail(Data));
                return Getuser;

            }
            catch (Exception ex)
            {

                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("ChangePassword")]
        public async Task<List<dynamic>> ChangePassword()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                UserMaster_Data userMaster_Data = new UserMaster_Data();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------ChangePassword Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------ChangePassword End--------------");
                var userMaster_DTO = JsonConvert.DeserializeObject<UserMaster_ChangePassword>(s);

                var userDetails = await Task.Run(() => userMaster_Data.ChangePassword(userMaster_DTO));
                userMaster_DTO.Type = 5;
                return userDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("ChangePasswordByEmail")]
        public async Task<List<dynamic>> ChangePasswordByEmail()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                UserMaster_Data userMaster_Data = new UserMaster_Data();
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                log.logDebugMessage("----------ChangePassword Start--------------");
                log.logDebugMessage(s);
                log.logDebugMessage("----------ChangePassword End--------------");
                var userMaster_DTO = JsonConvert.DeserializeObject<UserMaster_ChangePassword>(s);

                var userDetails = await Task.Run(() => userMaster_Data.ChangePasswordByEmail(userMaster_DTO));
                userMaster_DTO.Type = 5;
                return userDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }

        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateTyreMaster")]
        public async Task<List<dynamic>> CreateUpdate_Tyre_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Tyre_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Tyre_Master_DataDetails = await Task.Run(() => tyre_Master_Data.CreateUpdate_Tyre_Master_DataDetails(Data));

                return CreateUpdate_Tyre_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateTyreMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetTyreMaster")]
        public async Task<List<dynamic>> Get_Tyre_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Tyre_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Tyre_MasterDetails = await Task.Run(() => tyre_Master_Data.Get_Tyre_MasterDetails(Data));

                return Get_Tyre_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetTyreMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateBrandMaster")]
        public async Task<List<dynamic>> CreateUpdate_Brand_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Brand_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Brand_Master_DataDetails = await Task.Run(() => Brand_Master_Data.CreateUpdate_Brand_Master_DataDetails(Data));

                return CreateUpdate_Brand_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateBrandMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetBrandMaster")]
        public async Task<List<dynamic>> Get_Brand_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Brand_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Brand_MasterDetails = await Task.Run(() => Brand_Master_Data.Get_Brand_MasterDetails(Data));

                return Get_Brand_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetBrandMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateApplicationMaster")]
        public async Task<List<dynamic>> CreateUpdate_Application_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Application_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Application_Master_DataDetails = await Task.Run(() => application_Master_Data.CreateUpdate_Application_Master_DataDetails(Data));

                return CreateUpdate_Application_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateApplicationMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetApplicationMaster")]
        public async Task<List<dynamic>> Get_Application_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Application_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Application_MasterDetails = await Task.Run(() => application_Master_Data.Get_Application_MasterDetails(Data));

                return Get_Application_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetApplicationMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateSizeMaster")]
        public async Task<List<dynamic>> CreateUpdate_Size_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Size_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Size_Master_DataDetails = await Task.Run(() => size_Master_Data.CreateUpdate_Size_Master_DataDetails(Data));

                return CreateUpdate_Size_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateSizeMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetSizeMaster")]
        public async Task<List<dynamic>> Get_Size_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Size_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Size_MasterDetails = await Task.Run(() => size_Master_Data.Get_Size_MasterDetails(Data));

                return Get_Size_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetSizeMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateFleetMaster")]
        public async Task<List<dynamic>> CreateUpdate_Fleet_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Fleet_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Fleet_Master_DataDetails = await Task.Run(() => fleet_Master_Data.CreateUpdate_Fleet_Master_DataDetails(Data));

                return CreateUpdate_Fleet_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateFleetMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetFleetMaster")]
        public async Task<List<dynamic>> Get_Fleet_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Fleet_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Fleet_MasterDetails = await Task.Run(() => fleet_Master_Data.Get_Fleet_MasterDetails(Data));

                return Get_Fleet_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetFleetMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateTruckMaster")]
        public async Task<List<dynamic>> CreateUpdate_Truck_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Truck_Master_DataDetails = await Task.Run(() => truck_Master_Data.CreateUpdate_Truck_Master_DataDetails(Data));

                return CreateUpdate_Truck_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateTruckMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetTruckMaster")]
        public async Task<List<dynamic>> Get_Truck_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Truck_MasterDetails = await Task.Run(() => truck_Master_Data.Get_Truck_MasterDetails(Data));

                return Get_Truck_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetTruckMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetDropDownTyre")]
        public async Task<List<dynamic>> Get_DropDown_Tyre()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<DropDown_Tyre_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_DropDown_TyreDetails = await Task.Run(() => tyre_Master_Data.Get_DropDown_TyreDetails(Data));

                return Get_DropDown_TyreDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetDropDownTyre");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateTrukUserMaster")]
        public async Task<List<dynamic>> CreateUpdate_Truk_User_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truk_User_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Truk_User_Master_DataDetails = await Task.Run(() => Truk_User_Master_Data.CreateUpdate_Truk_User_Master_DataDetails(Data));

                return CreateUpdate_Truk_User_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateTrukUserMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetTrukUserMaster")]
        public async Task<List<dynamic>> Get_Truk_User_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truk_User_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Truk_User_MasterDetails = await Task.Run(() => Truk_User_Master_Data.Get_Truk_User_MasterDetails(Data));

                return Get_Truk_User_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetTrukUserMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateTruckOrderMaster")]
        public async Task<List<dynamic>> CreateUpdate_Truck_Order_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Order_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Truck_Order_Master_DataDetails = await Task.Run(() => Truck_Order_Master_Data.CreateUpdate_Truck_Order_Master_DataDetails(Data));

                return CreateUpdate_Truck_Order_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateTruckOrderMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetTruckOrderMaster")]
        public async Task<List<dynamic>> Get_Truck_Order_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Order_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Truck_Order_MasterDetails = await Task.Run(() => Truck_Order_Master_Data.Get_Truck_Order_MasterDetails(Data));

                return Get_Truck_Order_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetTruckOrderMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateTruckOrderChild")]
        public async Task<List<dynamic>> CreateUpdate_Truck_Order_Child()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Order_Child_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_Truck_Order_Child_DataDetails = await Task.Run(() => Truck_Order_Child_Data.CreateUpdate_Truck_Order_Child_DataDetails(Data));

                return CreateUpdate_Truck_Order_Child_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateTruckOrderChild");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetTruckOrderChild")]
        public async Task<List<dynamic>> Get_Truck_Order_Child()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<Truck_Order_Child_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_Truck_Order_ChildDetails = await Task.Run(() => Truck_Order_Child_Data.Get_Truck_Order_ChildDetails(Data));

                return Get_Truck_Order_ChildDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetTruckOrderChild");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }


        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("CreateUpdateUserAddressMaster")]
        public async Task<List<dynamic>> CreateUpdate_User_Address_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<User_Address_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var CreateUpdate_User_Address_Master_DataDetails = await Task.Run(() => User_Address_Master_Data.CreateUpdate_User_Address_Master_DataDetails(Data));

                return CreateUpdate_User_Address_Master_DataDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("CreateUpdateUserAddressMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        [Route("GetUserAddressMaster")]
        public async Task<List<dynamic>> Get_User_Address_Master()
        {
            List<dynamic> objdynamicobj = new List<dynamic>();

            try
            {
                System.IO.Stream body = System.Web.HttpContext.Current.Request.InputStream;
                System.Text.Encoding encoding = System.Web.HttpContext.Current.Request.ContentEncoding;
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                string s = reader.ReadToEnd();
                var Data = JsonConvert.DeserializeObject<User_Address_Master_DTO>(s);
                Data.UserID = LoggedInUserId;

                var Get_User_Address_MasterDetails = await Task.Run(() => User_Address_Master_Data.Get_User_Address_MasterDetails(Data));

                return Get_User_Address_MasterDetails;

            }
            catch (Exception ex)
            {
                log.logErrorMessage("GetUserAddressMaster");
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
                objdynamicobj.Add(ex.Message);
                return objdynamicobj;
            }
        }

    }
}
