﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace API.Repository.Project
{
    public class Truck_Order_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Truck_Order_Master(Truck_Order_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Truck_Order_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@TOM_PkeyID", 1 + "#bigint#" + model.TOM_PkeyID);
                input_parameters.Add("@TOM_User_Add_PkeyID", 1 + "#bigint#" + model.TOM_User_Add_PkeyID);
                input_parameters.Add("@TOM_Ord_ID", 1 + "#nvarchar#" + model.TOM_Ord_ID);
                input_parameters.Add("@TOM_User_PkeyID", 1 + "#bigint#" + model.TOM_User_PkeyID);
                input_parameters.Add("@TOM_Subtotal_Amount", 1 + "#decimal#" + model.TOM_Subtotal_Amount);
                input_parameters.Add("@TOM_Disc_Per", 1 + "#int#" + model.TOM_Disc_Per);
                input_parameters.Add("@TOM_Disc_Amount", 1 + "#decimal#" + model.TOM_Disc_Amount);
                input_parameters.Add("@TOM_Shipping_Amount", 1 + "#decimal#" + model.TOM_Shipping_Amount);
                input_parameters.Add("@TOM_Total_Amount", 1 + "#decimal#" + model.TOM_Total_Amount);
                input_parameters.Add("@TOM_Payment_Status", 1 + "#bit#" + model.TOM_Payment_Status);
                input_parameters.Add("@TOM_Ord_Date", 1 + "#datetime#" + model.TOM_Ord_Date);
                input_parameters.Add("@TOM_Ord_Status", 1 + "#int#" + model.TOM_Ord_Status);
                input_parameters.Add("@TOM_IsActive", 1 + "#bit#" + model.TOM_IsActive);
                input_parameters.Add("@TOM_IsDelete", 1 + "#bit#" + model.TOM_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@TOM_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }

        private DataSet Get_Truck_Order_Master(Truck_Order_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truck_Order_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TOM_PkeyID", 1 + "#bigint#" + model.TOM_PkeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }

        public List<dynamic> CreateUpdate_Truck_Order_Master_DataDetails(Truck_Order_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Truck_Order_Master(model);
                if(!string.IsNullOrWhiteSpace(model.Truck_Order_Child_DTO))
                {
                    var Data = JsonConvert.DeserializeObject<List<Truck_Order_Child_DTO>>(model.Truck_Order_Child_DTO);
                    for (int i = 0; i < Data.Count; i++)
                    {
                        Int64 Pkey = objData[0];
                        Truck_Order_Child_Data truck_Order_Child_Data = new Truck_Order_Child_Data();
                        Data[i].TOC_TOM_PkeyID = Pkey;
                        Data[i].Type = 1;
                        Data[i].UserID = model.UserID;
                        truck_Order_Child_Data.CreateUpdate_Truck_Order_Child_DataDetails(Data[i]);
                    }

                }
               

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        private List<Truck_Order_Child_DTO> GetChildData(DataTable dt )
        {
            List<Truck_Order_Child_DTO> Truck_Order_Child_DTO = new List<Truck_Order_Child_DTO>();

            try
            {
                var myEnumerableFeaprd =dt.AsEnumerable();
                Truck_Order_Child_DTO =
                     (from item in myEnumerableFeaprd
                      select new Truck_Order_Child_DTO
                      {
                          TOC_PkeyID = item.Field<Int64>("TOC_PkeyID"),
                          TOC_TOM_PkeyID = item.Field<Int64?>("TOC_TOM_PkeyID"),
                          TOC_Tyre_PKeyID = item.Field<Int64?>("TOC_Tyre_PKeyID"),
                          TOC_Qty = item.Field<int?>("TOC_Qty"),
                          TOC_Tyre_Price = item.Field<Decimal?>("TOC_Tyre_Price"),
                          TOC_Disc_Per = item.Field<Decimal?>("TOC_Disc_Per"),
                          TOC_Disc_Amount = item.Field<Decimal?>("TOC_Disc_Amount"),
                          TOC_Total_Amount = item.Field<Decimal?>("TOC_Total_Amount"),
                          TOC_User_PkeyID = item.Field<Int64?>("TOC_User_PkeyID"),
                          TOC_IsActive = item.Field<Boolean?>("TOC_IsActive"),
                      }).ToList();

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return Truck_Order_Child_DTO;

        }

        public List<dynamic> Get_Truck_Order_MasterDetails(Truck_Order_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truck_Order_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Truck_Order_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Truck_Order_Master_DTO
                    {
                        TOM_PkeyID = item.Field<Int64>("TOM_PkeyID"),
                        TOM_User_Add_PkeyID = item.Field<Int64?>("TOM_User_Add_PkeyID"),
                        TOM_Ord_ID = item.Field<String>("TOM_Ord_ID"),
                        TOM_User_PkeyID = item.Field<Int64?>("TOM_User_PkeyID"),
                        TOM_Subtotal_Amount = item.Field<Decimal?>("TOM_Subtotal_Amount"),
                        TOM_Disc_Per = item.Field<int?>("TOM_Disc_Per"),
                        TOM_Disc_Amount = item.Field<Decimal?>("TOM_Disc_Amount"),
                        TOM_Shipping_Amount = item.Field<Decimal?>("TOM_Shipping_Amount"),
                        TOM_Total_Amount = item.Field<Decimal?>("TOM_Total_Amount"),
                        TOM_Payment_Status = item.Field<Boolean?>("TOM_Payment_Status"),
                        TOM_Ord_Date = item.Field<DateTime?>("TOM_Ord_Date"),
                        TOM_Ord_Status = item.Field<int?>("TOM_Ord_Status"),
                        TOM_IsActive = item.Field<Boolean?>("TOM_IsActive"),
                        truck_Order_Child_DTOs = GetChildData(ds.Tables[1])

                    }).ToList();

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}