﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Get_Truck_User_Master_Company_DTO
    {

        public Int64 TUM_PKeyID { get; set; }
        public Int64? TUM_TR_PKeyID { get; set; }
        public String TUM_TruckNo { get; set; }
        public String TUM_Model { get; set; }
        public int? TUM_Mileage { get; set; }
        public Int64? TUM_User_PkeyID { get; set; }
        public String TR_Name { get; set; }
        public String TR_Description { get; set; }
        public String TR_ImagePath { get; set; }
        public String TR_TruckNo { get; set; }
        public String User_Name { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }

    }
}