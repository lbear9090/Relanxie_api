﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Truk_User_Master_DTO
    {
        public Int64 TUM_PKeyID { get; set; }
        public Int64? TUM_TR_PKeyID { get; set; }
        public Int64? TUM_User_PkeyID { get; set; }
        public String TUM_TruckNo { get; set; }
        public String TUM_Model { get; set; }
        public int?  TUM_Mileage { get; set; }
        public DateTime? TUM_Tyre_Date { get; set; }
        public Boolean? TUM_IsActive { get; set; }
        public Boolean? TUM_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }

    }
}