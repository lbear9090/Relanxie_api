﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Brand_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Brand_Master(Brand_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Brand_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@BR_PKeyID", 1 + "#bigint#" + model.BR_PKeyID);
                input_parameters.Add("@BR_Name", 1 + "#varchar#" + model.BR_Name);
                input_parameters.Add("@BR_Description", 1 + "#nvarchar#" + model.BR_Description);
                input_parameters.Add("@BR_ImagePath", 1 + "#nvarchar#" + model.BR_ImagePath);
                input_parameters.Add("@BR_IsActive", 1 + "#bit#" + model.BR_IsActive);
                input_parameters.Add("@BR_IsDelete", 1 + "#bit#" + model.BR_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@BR_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Brand_Master(Brand_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Brand_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@BR_PKeyID", 1 + "#bigint#" + model.BR_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> CreateUpdate_Brand_Master_DataDetails(Brand_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Brand_Master(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        public List<dynamic> Get_Brand_MasterDetails(Brand_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Brand_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Brand_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Brand_Master_DTO
                    {
                        BR_PKeyID = item.Field<Int64>("BR_PKeyID"),
                        BR_Name = item.Field<String>("BR_Name"),
                        BR_Description = item.Field<String>("BR_Description"),
                        BR_ImagePath = item.Field<String>("BR_ImagePath"),
                        BR_IsActive = item.Field<Boolean?>("BR_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}