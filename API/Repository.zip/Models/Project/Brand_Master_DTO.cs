﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Brand_Master_DTO
    {
        public Int64 BR_PKeyID { get; set; }
        public String BR_Name { get; set; }
        public String BR_Description { get; set; }
        public String BR_ImagePath { get; set; }
        public Boolean? BR_IsActive { get; set; }
        public Boolean? BR_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}