﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Size_Master_DTO
    {
        public Int64 SZ_PKeyID { get; set; }
        public String SZ_Name { get; set; }
        public String SZ_Description { get; set; }
        public Int64? SZ_ID { get; set; }
        public Boolean? SZ_IsActive { get; set; }
        public Boolean? SZ_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}