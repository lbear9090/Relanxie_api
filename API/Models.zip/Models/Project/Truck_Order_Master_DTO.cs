﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Truck_Order_Master_DTO
    {
        public Int64 TOM_PkeyID { get; set; }
        public Int64? TOM_User_Add_PkeyID { get; set; }
        public String TOM_Ord_ID { get; set; }
        public Int64? TOM_User_PkeyID { get; set; }
        public Decimal? TOM_Subtotal_Amount { get; set; }
        public int? TOM_Disc_Per { get; set; }
        public Decimal? TOM_Disc_Amount { get; set; }
        public Decimal? TOM_Shipping_Amount { get; set; }
        public Decimal? TOM_Total_Amount { get; set; }
        public Boolean? TOM_Payment_Status { get; set; }
        public DateTime? TOM_Ord_Date { get; set; }
        public int? TOM_Ord_Status { get; set; }
        public Boolean? TOM_IsActive { get; set; }
        public Boolean? TOM_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
        public string Truck_Order_Child_DTO { get; set; }
        public List<Truck_Order_Child_DTO> truck_Order_Child_DTOs { get; set; }

    }
}