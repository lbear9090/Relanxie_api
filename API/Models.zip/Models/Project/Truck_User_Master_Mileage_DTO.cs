﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Truck_User_Master_Mileage_DTO
    {

        public Int64 TUMM_PKeyID { get; set; }
        public Int64? TUMM_TUM_PKeyID { get; set; }
        public Boolean? TUMM_Tyre_General_Condition { get; set; }
        public Boolean? TUMM_Torque_Checked { get; set; }
        public Boolean? TUMM_Tread_Depth { get; set; }
        public Boolean? TUMM_Trye_Pressure { get; set; }
        public String TUMM_Comments { get; set; }
        public int? TUMM_Mileage { get; set; }
        public DateTime? TUMM_Last_Inspection { get; set; }
        public Boolean? TUMM_IsActive { get; set; }
        public Boolean? TUMM_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}