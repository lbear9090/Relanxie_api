﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Product_Image_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();
        private List<dynamic> CreateUpdate_Product_Image(Product_Image_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Product_Image]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@ProImage_ID", 1 + "#bigint#" + model.ProImage_ID);
                input_parameters.Add("@ProImage_Pro_ID", 1 + "#bigint#" + model.ProImage_Pro_ID);
                input_parameters.Add("@ProImage_ImageName", 1 + "#nvarchar#" + model.ProImage_ImageName);
                input_parameters.Add("@ProImage_size", 1 + "#int#" + model.ProImage_size);
                input_parameters.Add("@ProImage_ImagePath ", 1 + "#nvarchar#" + model.ProImage_ImagePath);
                input_parameters.Add("@ProImage_IsFirst", 1 + "#bit#" + model.ProImage_IsFirst);
                input_parameters.Add("@ProImage_Number", 1 + "#int#" + model.ProImage_Number); 
                input_parameters.Add("@ProImage_IsActive", 1 + "#bit#" + model.ProImage_IsActive);
                input_parameters.Add("@ProImage_IsDelete", 1 + "#bit#" + model.ProImage_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@ProImage_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Product_Image(Product_Image_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Product_Image]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@ProImage_ID", 1 + "#bigint#" + model.ProImage_ID);
                input_parameters.Add("@ProImage_Pro_ID", 1 + "#bigint#" + model.ProImage_Pro_ID);
               
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> CreateUpdate_Product_Image_DataDetails(Product_Image_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Product_Image(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }
        public List<dynamic> Get_Product_ImageDetails(Product_Image_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Product_Image(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Product_Image_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Product_Image_DTO
                    {
                        ProImage_ID = item.Field<Int64>("ProImage_ID"),
                        ProImage_Pro_ID = item.Field<Int64?>("ProImage_Pro_ID"),
                        ProImage_ImageName = item.Field<String>("ProImage_ImageName"),
                        ProImage_size = item.Field<int?>("ProImage_size"),
                        ProImage_ImagePath = item.Field<String>("ProImage_ImagePath"),
                        ProImage_IsFirst = item.Field<Boolean?>("ProImage_IsFirst"),
                        ProImage_Number = item.Field<int?>("ProImage_Number"),
                        ProImage_IsActive = item.Field<Boolean?>("ProImage_IsActive"),
                    }).ToList();



                objDynamic.Add(Get_details);

            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }


    }
}