﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Truck_Order_Child_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Truck_Order_Child(Truck_Order_Child_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Truck_Order_Child]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@TOC_PkeyID", 1 + "#bigint#" + model.TOC_PkeyID);
                input_parameters.Add("@TOC_TOM_PkeyID", 1 + "#bigint#" + model.TOC_TOM_PkeyID);
                input_parameters.Add("@TOC_Tyre_PKeyID", 1 + "#bigint#" + model.TOC_Tyre_PKeyID);
                input_parameters.Add("@TOC_Qty", 1 + "#int#" + model.TOC_Qty);
                input_parameters.Add("@TOC_Tyre_Price", 1 + "#decimal#" + model.TOC_Tyre_Price);
                input_parameters.Add("@TOC_Disc_Per", 1 + "#decimal#" + model.TOC_Disc_Per);
                input_parameters.Add("@TOC_Disc_Amount", 1 + "#decimal#" + model.TOC_Disc_Amount);
                input_parameters.Add("@TOC_Total_Amount ", 1 + "#decimal#" + model.TOC_Total_Amount);
                input_parameters.Add("@TOC_User_PkeyID", 1 + "#bigint#" + model.TOC_User_PkeyID);
                input_parameters.Add("@TOC_IsActive", 1 + "#bit#" + model.TOC_IsActive);
                input_parameters.Add("@TOC_IsDelete", 1 + "#bit#" + model.TOC_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@TOC_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Truck_Order_Child(Truck_Order_Child_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truck_Order_Child]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TOC_PkeyID", 1 + "#bigint#" + model.TOC_PkeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }


        public List<dynamic> CreateUpdate_Truck_Order_Child_DataDetails(Truck_Order_Child_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Truck_Order_Child(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }


        public List<dynamic> Get_Truck_Order_ChildDetails(Truck_Order_Child_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truck_Order_Child(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Truck_Order_Child_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Truck_Order_Child_DTO
                    {
                        TOC_PkeyID = item.Field<Int64>("TOC_PkeyID"),
                        TOC_TOM_PkeyID = item.Field<Int64?>("TOC_TOM_PkeyID"),
                        TOC_Tyre_PKeyID = item.Field<Int64?>("TOC_Tyre_PKeyID"),
                        TOC_Qty = item.Field<int?>("TOC_Qty"),
                        TOC_Tyre_Price = item.Field<Decimal?>("TOC_Tyre_Price"),
                        TOC_Disc_Per = item.Field<Decimal?>("TOC_Disc_Per"),
                        TOC_Disc_Amount = item.Field<Decimal?>("TOC_Disc_Amount"),
                        TOC_Total_Amount = item.Field<Decimal?>("TOC_Total_Amount"),
                        TOC_User_PkeyID = item.Field<Int64?>("TOC_User_PkeyID"),
                        TOC_IsActive = item.Field<Boolean?>("TOC_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}