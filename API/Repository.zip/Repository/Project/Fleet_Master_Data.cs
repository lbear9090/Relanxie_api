﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Fleet_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Fleet_Master(Fleet_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Fleet_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@FL_PKeyID", 1 + "#bigint#" + model.FL_PKeyID);
                input_parameters.Add("@FL_Name ", 1 + "#varchar#" + model.FL_Name);
                input_parameters.Add("@FL_Description", 1 + "#nvarchar#" + model.FL_Description);
                input_parameters.Add("@FL_ImagePath", 1 + "#nvarchar#" + model.FL_ImagePath);
                input_parameters.Add("@FL_IsActive", 1 + "#bit#" + model.FL_IsActive);
                input_parameters.Add("@FL_IsDelete", 1 + "#bit#" + model.FL_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@FL_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Fleet_Master(Fleet_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Fleet_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@FL_PKeyID", 1 + "#bigint#" + model.FL_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> CreateUpdate_Fleet_Master_DataDetails(Fleet_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Fleet_Master(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }
        public List<dynamic> Get_Fleet_MasterDetails(Fleet_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Fleet_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Fleet_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Fleet_Master_DTO
                    {
                        FL_PKeyID = item.Field<Int64>("FL_PKeyID"),
                        FL_Name = item.Field<String>("FL_Name"),
                        FL_Description = item.Field<String>("FL_Description"),
                        FL_ImagePath = item.Field<String>("FL_ImagePath"),
                        FL_IsActive = item.Field<Boolean?>("FL_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}