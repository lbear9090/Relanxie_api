﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Size_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Size_Master(Size_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Size_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@SZ_PKeyID", 1 + "#bigint#" + model.SZ_PKeyID);
                input_parameters.Add("@SZ_Name", 1 + "#varchar#" + model.SZ_Name);
                input_parameters.Add("@SZ_Description", 1 + "#nvarchar#" + model.SZ_Description);
                input_parameters.Add("@SZ_ID", 1 + "#bigint#" + model.SZ_ID);
                input_parameters.Add("@SZ_IsActive", 1 + "#bit#" + model.SZ_IsActive);
                input_parameters.Add("@SZ_IsDelete", 1 + "#bit#" + model.SZ_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@SZ_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }
        private DataSet Get_Size_Master(Size_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Size_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@SZ_PKeyID", 1 + "#bigint#" + model.SZ_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }
        public List<dynamic> CreateUpdate_Size_Master_DataDetails(Size_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Size_Master(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        public List<dynamic> Get_Size_MasterDetails(Size_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Size_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Size_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Size_Master_DTO
                    {
                        SZ_PKeyID = item.Field<Int64>("SZ_PKeyID"),
                        SZ_Name = item.Field<String>("SZ_Name"),
                        SZ_Description = item.Field<String>("SZ_Description"),
                        SZ_ID = item.Field<Int64>("SZ_ID"),
                        SZ_IsActive = item.Field<Boolean?>("SZ_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}