﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models.Project
{
    public class Product_Image_DTO
    {
        public Int64 ProImage_ID { get; set; }
        public Int64? ProImage_Pro_ID { get; set; }
        public String ProImage_ImageName { get; set; }
        public int? ProImage_size { get; set; }
        public String ProImage_ImagePath { get; set; }
        public Boolean? ProImage_IsFirst { get; set; }
        public int? ProImage_Number { get; set; }
        public Boolean? ProImage_IsActive { get; set; }
        public Boolean? ProImage_IsDelete { get; set; }
        public int? Type { get; set; }
        public Int64? UserID { get; set; }
    }
}