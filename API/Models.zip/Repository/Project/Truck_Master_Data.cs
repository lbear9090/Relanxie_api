﻿using Avigma.Repository.Lib;
using Avigma.Repository.Security;
using API.Models.Project;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace API.Repository.Project
{
    public class Truck_Master_Data
    {
        MyDataSourceFactory obj = new MyDataSourceFactory();
        Log log = new Log();
        SecurityHelper securityHelper = new SecurityHelper();

        private List<dynamic> CreateUpdate_Truck_Master(Truck_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();

            string insertProcedure = "[CreateUpdate_Truck_Master]";

            Dictionary<string, string> input_parameters = new Dictionary<string, string>();
            try
            {
                input_parameters.Add("@TR_PKeyID", 1 + "#bigint#" + model.TR_PKeyID);
                input_parameters.Add("@TR_Name", 1 + "#varchar#" + model.TR_Name);
                input_parameters.Add("@TR_Description", 1 + "#nvarchar#" + model.TR_Description);
                input_parameters.Add("@TR_ImagePath", 1 + "#nvarchar#" + model.TR_ImagePath);
                input_parameters.Add("@TR_TruckNo", 1 + "#nvarchar#" + model.TR_TruckNo);
                input_parameters.Add("@TR_NoOfTyre", 1 + "#int#" + model.TR_NoOfTyre);
                input_parameters.Add("@TR_IsActive", 1 + "#bit#" + model.TR_IsActive);
                input_parameters.Add("@TR_IsDelete", 1 + "#bit#" + model.TR_IsDelete);
                input_parameters.Add("@Type", 1 + "#int#" + model.Type);
                input_parameters.Add("@UserID", 1 + "#bigint#" + model.UserID);
                input_parameters.Add("@TR_PkeyID_Out", 2 + "#bigint#" + null);
                input_parameters.Add("@ReturnValue", 2 + "#int#" + null);
                objData = obj.SqlCRUD(insertProcedure, input_parameters);


            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }
            return objData;



        }

        private DataSet Get_Truck_Master(Truck_Master_DTO model)
        {
            DataSet ds = null;
            try
            {
                string selectProcedure = "[Get_Truck_Master]";
                Dictionary<string, string> input_parameters = new Dictionary<string, string>();

                input_parameters.Add("@TR_PKeyID", 1 + "#bigint#" + model.TR_PKeyID);

                input_parameters.Add("@Type", 1 + "#int#" + model.Type);

                ds = obj.SelectSql(selectProcedure, input_parameters);
            }

            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }



            return ds;
        }

        public List<dynamic> CreateUpdate_Truck_Master_DataDetails(Truck_Master_DTO model)
        {
            List<dynamic> objData = new List<dynamic>();
            try
            {
                objData = CreateUpdate_Truck_Master(model);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.Message);
                log.logErrorMessage(ex.StackTrace);
            }
            return objData;
        }

        public List<dynamic> Get_Truck_MasterDetails(Truck_Master_DTO model)
        {
            List<dynamic> objDynamic = new List<dynamic>();
            try
            {

                DataSet ds = Get_Truck_Master(model);

                var myEnumerableFeaprd = ds.Tables[0].AsEnumerable();
                List<Truck_Master_DTO> Get_details =
                   (from item in myEnumerableFeaprd
                    select new Truck_Master_DTO
                    {
                        TR_PKeyID = item.Field<Int64>("TR_PKeyID"),
                        TR_Name = item.Field<String>("TR_Name"),
                        TR_Description = item.Field<String>("TR_Description"),
                        TR_ImagePath = item.Field<String>("TR_ImagePath"),
                        TR_TruckNo = item.Field<String>("TR_TruckNo"),
                        TR_NoOfTyre = item.Field<int?>("TR_NoOfTyre"),
                        TR_IsActive = item.Field<Boolean?>("TR_IsActive"),
                    }).ToList();

                objDynamic.Add(Get_details);
            }
            catch (Exception ex)
            {
                log.logErrorMessage(ex.StackTrace);
                log.logErrorMessage(ex.Message);
            }

            return objDynamic;
        }
    }
}